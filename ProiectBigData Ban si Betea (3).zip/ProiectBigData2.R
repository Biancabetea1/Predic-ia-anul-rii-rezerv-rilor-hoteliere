# incarcarea bibliotecilor necesare
library(readr)
library(tidyverse)
library(ggplot2)
library(dplyr)
library(rsample)
library(caret)
library(rpart)
library(rpart.plot)
library(corrplot)
library(pROC)
library(randomForest)

#incarcarea setului de date si verificarea structurii
data <- read_csv("Hotel Reservations.csv")
view(data)
summary(data)                         
str(data)

data <- subset(data, select = -Booking_ID) # elimina coloana Booking_ID
# adaugarea unei noi coloane 'no_of_persons'
data <- data %>%
    mutate(no_of_persons = no_of_adults + no_of_children)

# adaugarea unei noi coloane 'no_of_nights' 
data <- data %>%
    mutate(no_of_nights = no_of_weekend_nights + no_of_week_nights)

# codificarea lunilor de sosire in anotimpuri 
data <- data %>%
  mutate(season = case_when(
    arrival_month %in% c(12, 1, 2) ~ "Winter",
    arrival_month %in% c(3, 4, 5) ~ "Spring",
    arrival_month %in% c(6, 7, 8) ~ "Summer",
    arrival_month %in% c(9, 10, 11) ~ "Autumn"))

# stergere variabile nefolositore
data <- subset(data, select = -no_of_adults) 
data <- subset(data, select = -no_of_children)
data <- subset(data, select = -no_of_weekend_nights)
data <- subset(data, select = -no_of_week_nights)
data <- subset(data, select = -arrival_month )
data <- subset(data, select = -arrival_year)
data <- subset(data, select = -arrival_date)

valori_lipsa <- colSums(is.na(data))  # Verificarea valorilor lipsă
print(valori_lipsa)
data <- data %>% drop_na()            # tratarea valorilor lipsa (daca exista)

#transformarea coloanelor nenumerice in factor
data$type_of_meal_plan <- as.factor(data$type_of_meal_plan)
data$room_type_reserved <- as.factor(data$room_type_reserved)
data$market_segment_type <- as.factor(data$market_segment_type)
data$booking_status <- as.factor(data$booking_status)
data$season <- as.factor(data$season)
view(data)

# vizualizarea distributiei variabilelor numerice
data %>%
  select_if(is.numeric) %>%
  gather(metric, value) %>%
  ggplot(aes(value, fill=metric)) +
  geom_density(show.legend = FALSE) +
  facet_wrap(~metric, scales = "free")

# corelarea variabilelor numerice
data %>%
  select_if(is.numeric) %>%
  cor() %>%
  corrplot::corrplot()
#eliminare variabile cu distributie dezechilibrata
data <- data %>%
  select(-no_of_previous_bookings_not_canceled, -no_of_previous_cancellations)
str(data)

#Vizualizari
# 1 Distributia variabilei booking_status
ggplot(data, aes(x = booking_status)) + 
  geom_bar() + 
  labs(title = "Distributia statutului rezervarii", x = "Statutul rezervarii",
       y = "Numarul de rezervari")

# 2 distributia lead_time in functie de statusul rezervarii
ggplot(data, aes(x = lead_time, fill = booking_status)) + 
  geom_histogram(bins = 30, position = "dodge") + 
  labs(title = "Distributia timpului de asteptare in functie de statusul rezervarii", 
       x = "Timpul de asteptare (lead time)", y = "Numarul de rezervari") 

# 3 histograma a anotimpurilor in functie de starea rezervarii
ggplot(data, aes(x = season, fill = season)) +
  geom_bar() +
  labs(title = "Anotimpul cel mai frecvent in functie de statusul rezervarii", 
       y = "Numar de rezervari in fiecare anotimp", x = "Anotimpul") +
  facet_wrap(~booking_status) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# impartirea setului de date in seturi de antrenament si test dupa atributul booking_status
set.seed(123)         # pentru reproductibilitatea rezultatelor
split <- initial_split(data, prop = 0.7, strata = "booking_status")
train <- training(split)
test <- testing(split)
# verificarea distributiei variabilei booking_status in setul de date de antrenament si de test
table(train$booking_status)
table(test$booking_status)

# stabilesc ca metoda de validare 10-folds cross-validation
train_control <- trainControl(method = "cv",number = 10 )

# setarea atributelor independente 
features <- setdiff(names(data), "booking_status")
x <- train[, features]
y <- train$booking_status  # atributul tinta

# Modelul Naive Bayes
# invatarea modelului
mod_nb1 <- train( x = x,  y = y,  method = "nb",  trControl = train_control )
# predictii
pred_nb1 <- predict(mod_nb1, test)
# afisarea matricei de confuzie pentru mod_nb1
conf_matrix_nb1 <- confusionMatrix(pred_nb1, factor(test$booking_status))
print(conf_matrix_nb1)

# grid de cautare pentru ajustarea parametrilor
searchGrid <- expand.grid(   # creaza toate combinatiile posibile de valori ale parametrilor.
  usekernel = c(TRUE, FALSE),
  fL = 0.5,                  # folosirea metodei Laplace pentru netezire
  adjust = seq(0, 4, by = 1) # ajustarea latimii de banda a functiilor kernel
)

# reantrenarea modelului Naive Bayes cu grid de cautare
mod_nb2 <- train( x = x,y = y,method = "nb",trControl = train_control,tuneGrid = searchGrid)
confusionMatrix(mod_nb2)
# cele mai bune modele in urma cautari(dupa acuratete)
mod_nb2$results %>%
  top_n(5, wt = Accuracy) %>%
  arrange(desc(Accuracy))

# Afișarea matricei de confuzie pentru mod_nb2 pe datele de test
pred_nb2 <- predict(mod_nb2, test)
conf_matrix_nb2 <- confusionMatrix(pred_nb2, factor(test$booking_status))
print(conf_matrix_nb2)

# curbele ROC pentru modelul inițial și cel ajustat
roc_nb1 <- roc(test$booking_status, as.numeric(pred_nb1))
roc_nb2 <- roc(test$booking_status, as.numeric(pred_nb2))
plot(roc_nb1, col = "blue", main = "ROC Curve for Naive Bayes Models")
lines(roc_nb2, col = "red")
legend("bottomright", legend = c("Initial", "Adjusted"), col = c("blue", "red"))


# 2.Regresia logistica
# antrenarea modelului de regresie logistica folosind cross-validation
model_logistic <- train(x=x, y=y, method = "glm", family = "binomial", 
                        trControl = train_control)
# predictii pe setul de testare
pred_logistic <- predict(model_logistic, test)
# evaluarea performantei modelului utilizand matricea de confuzie
conf_matrix_logistic <- confusionMatrix(pred_logistic, factor(test$booking_status))
print(conf_matrix_logistic)
# afisarea coeficientilor modelului 
summary(model_logistic)

# eliminare atribute cu p-valori mari
x_sel <- x %>% select(-type_of_meal_plan, -market_segment_type, -room_type_reserved)
model_logistic_nou <- train(x=x_sel, y=y, method = "glm", 
      family = "binomial", trControl = train_control)
# predictii pe setul de testare
pred_logistic_nou <- predict(model_logistic_nou, test)
# evaluarea performantei modelului utilizand matricea de confuzie
conf_matrix_logistic_nou <- confusionMatrix(pred_logistic_nou, factor(test$booking_status))
print(conf_matrix_logistic_nou)

# curbele ROC pentru modelul inițial și cel ajustat
roc_l1 <- roc(test$booking_status, as.numeric(pred_logistic))
roc_l2 <- roc(test$booking_status, as.numeric(pred_logistic_nou))
plot(roc_l1, col = "blue", main = "ROC Curve for Logistic Regresion Models")
lines(roc_l2, col = "red")
legend("bottomright", legend = c("Initial", "Adjusted"), col = c("blue", "red"))


# 3.Arbore de decizie
# construirea modelului de arbore de decizie cu cross-validation
model_tree <- train(x=x, y=y, method = "rpart", trControl = train_control)
# vizualizarea arborelui de decizie
rpart.plot(model_tree$finalModel)   # arborele de decizie in sine este stocat în finalModel
# predictii pe setul de testare pt. model_tree
pred_tree <- predict(model_tree, newdata = test)
# matricea de confuzie
conf_matrix_tree <- confusionMatrix(pred_tree, factor(test$booking_status))
print(conf_matrix_tree)

# grid de cautare pentru ajustarea parametrilor
hyperGrid <- expand.grid(  cp = seq(0.01, 0.1, by = 0.01))

# antrenarea modelului de arbore de decizie cu ajustare de parametri 
model_tree2 <- train(x=x, y=y, method = "rpart", trControl = train_control, tuneGrid = hyperGrid)
      
# Predictii pe setul de testare cu model_tree2
pred_tree2 <- predict(model_tree2, newdata = test)
conf_matrix_tree2 <- confusionMatrix(pred_tree2, factor(test$booking_status))
print(conf_matrix_tree2)

# curbele ROC pentru modelul initial și cel ajustat
roc_t1 <- roc(test$booking_status, as.numeric(pred_tree))
roc_t2 <- roc(test$booking_status, as.numeric(pred_tree2))
# Plotarea curbelor ROC
plot(roc_t1, col = "blue", main = "ROC Curve for Decision Tree Models")
lines(roc_t2, col = "red")
legend("bottomright", legend = c("Initial", "Adjusted"), col = c("blue", "red"))


# Antrenarea modelului Random Forest cu cross-validation
model_rf <- train(x=x, y=y, method = "rf", trControl = train_control, tree =100)
# predictii pe setul de testare
pred_rf <- predict(model_rf, newdata = test)
# evaluarea performantei modelului Random Forest
conf_matrix_rf <- confusionMatrix(pred_rf, as.factor(test$booking_status))
print(conf_matrix_rf)

# apelarea functiei tuneRF pentru a ajusta parametrul mtry
model_rf_tuned <- tuneRF(
  x = x,
  y = y,
  ntreeTry = 500,
  mtryStart = 5,  # incepe cu 5 variabile si creste cu un factor de 1.7
  stepFactor = 1.7,
  improve = 0.01, # se opreste cand imbunatatirea este mai mica de 1%
  trace = FALSE
)

# aleg cel mai bun mtry din modelul ajustat
best_mtry <- model_rf_tuned[which.min(model_rf_tuned[, "OOBError"]), "mtry"]

# antrenarea modelului Random Forest ajustat cu cel mai bun mtry
model_rf_nou <- train(x = x, y = y, method = "rf", trControl = train_control, 
                    tuneGrid = expand.grid(mtry = best_mtry), ntree = 500)
# predictii pe setul de testare pentru modelul ajustat
pred_rf_nou <- predict(model_rf_nou, newdata = test)
# evaluarea performanței modelului Random Forest ajustat
conf_matrix_rf_nou <- confusionMatrix(pred_rf_nou, factor(test$booking_status))
print(conf_matrix_rf_nou)

#  ROC pentru modelul initial si cel ajustat
roc_f1 <- roc(test$booking_status, as.numeric(pred_rf))
roc_f2 <- roc(test$booking_status, as.numeric(pred_rf_nou))
plot(roc_f1, col = "blue", main = "ROC Curve for Random Forest Models")
lines(roc_t2, col = "red")
legend("bottomright", legend = c("Initial", "Adjusted"), col = c("blue", "red"))

# Afișarea centralizată a rezultatelor
# functie pentru afisarea metricilor 
show_metrics <- function(conf_matrix) {
  accuracy <- conf_matrix$overall["Accuracy"]
  sensitivity <- conf_matrix$byClass["Sensitivity"]
  specificity <- conf_matrix$byClass["Specificity"]
  cat("Accuracy:", accuracy, "\n")
  cat("Sensitivity:", sensitivity, "\n")
  cat("Specificity:", specificity, "\n")
}

show_metrics(conf_matrix_nb1)
show_metrics(conf_matrix_nb2)
show_metrics(conf_matrix_logistic)
show_metrics(conf_matrix_logistic_nou)
show_metrics(conf_matrix_tree)
show_metrics(conf_matrix_tree2)
show_metrics(conf_matrix_rf)
show_metrics(conf_matrix_rf_nou)

# Compararea performanței modelelor
results <- resamples(list(
  NaiveBayes1 = mod_nb1,
  NaiveBayes2 = mod_nb2,
  LogisticRegression1 = model_logistic,
  LogisticRegression2 = model_logistic_nou,
  Tree1 = model_tree, 
  Tree2 = model_tree2,
  RandomForest1 = model_rf,
  RandomForest2 = model_rf_nou
))
# Sumarul rezultatelor
summary(results)
dotplot(results)

# calcularea importantei variabilelor pentru modelul ales:Random Forest ajustat
importance_rf_nou <- varImp(model_rf_nou, scale = FALSE)
#extrage importanta variabilelor ca data frame
importance_df <- as.data.frame(importance_rf_nou$importance)
# adauga numele variabilelor in data frame
importance_df$Variable <- rownames(importance_df)
# sortează importanta variabilelor in ordine descrescatoare
importance_df <- importance_df[order(-importance_df$Overall), ]
# Afișează importanța variabilelor sortate
print(importance_df)

# vizualizarea importantei variabilelor sortate
ggplot(importance_df, aes(x = reorder(Variable, Overall), y = Overall)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  xlab("Variable") +
  ylab("Importance") +
  ggtitle("Variable Importance - Random Forest") 

# predictia probabilitatii de anulare folosind Random Forest ajustat
pred_prob_rf_nou <- predict(model_rf_nou, newdata = test, type = "prob")
# adaugarea probabilitătilor prezise la datele de test
test_with_preds <- test %>%
  mutate(pred_prob = pred_prob_rf_nou[, "Canceled"],
         booking_status = factor(test$booking_status, levels = c("Not_Canceled", "Canceled")))

# distributiei probabilitătilor prezise pe anotimpuri
ggplot(test_with_preds, aes(x = season, y = pred_prob, fill = season)) +
  geom_boxplot() +
  labs(title = "Predicted Probability of Cancellations by Season",
       x = "Season",
       y = "Predicted Probability of Cancellation") 







